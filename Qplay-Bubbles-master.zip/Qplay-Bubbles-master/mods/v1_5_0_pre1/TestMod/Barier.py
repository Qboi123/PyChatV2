from versions.v1_5_0_pre1.base import BaseBarier


class Barier(BaseBarier):
    def __init__(self):
        super().__init__()